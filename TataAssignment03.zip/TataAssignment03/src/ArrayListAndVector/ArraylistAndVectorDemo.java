/**
 * 
 */
package ArrayListAndVector;

/**
 * @author Tejo Lakshmi Tata
 *
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;



public class ArraylistAndVectorDemo {


		    public static  void main(String[] args) {
		        // Creating an ArrayList
		        List<String> arrayList = new ArrayList<>();
		        arrayList.add("Volvo");
		        arrayList.add("Black");
		        arrayList.add("cherry");

		        // Creating a Vector
		        Vector<String> vector = new Vector<>();
		        vector.add("Bmw");
		        vector.add("White");
		        vector.add("Car");

		        // Iterating over the ArrayList
		        System.out.println("ArrayList:");
		        for (String s : arrayList) {
		            System.out.println(s);
		        }

		        // Iterating over the Vector
		        System.out.println("Vector:");
		        for (String s : vector) {
		            System.out.println(s);
		        }
		    
		}
}

	


