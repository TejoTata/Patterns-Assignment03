/**
 * 
 */
package HashMapandHashTable;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class HashMapAndHashTableDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 Map<String, Integer> hashtable = new Hashtable<>();
	        hashtable.put("apple", 1);
	        hashtable.put("banana", 2);
	        hashtable.put("cherry", 3);

	        // Creating a HashMap
	        Map<String, Integer> hashMap = new HashMap<>();
	        hashMap.put("apple", 1);
	        hashMap.put("banana", 2);
	        hashMap.put("cherry", 3);

	        // Printing the contents of the Hashtable
	        System.out.println("Hashtable: " + hashtable);

	        // Printing the contents of the HashMap
	        System.out.println("HashMap: " + hashMap);

	        // Retrieving the value of a key from the Hashtable
	        System.out.println("Value of 'apple' in Hashtable: " + hashtable.get("apple"));

	        // Retrieving the value of a key from the HashMap
	        System.out.println("Value of 'apple' in HashMap: " + hashMap.get("apple"));

		
	}

}
