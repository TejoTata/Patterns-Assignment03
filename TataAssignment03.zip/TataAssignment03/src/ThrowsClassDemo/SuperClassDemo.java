/**
 * 
 */
package ThrowsClassDemo;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class SuperClassDemo {
	public static void main(String[] args) {
	
	SuperClassDemo x = new SubClassDemo();
	}
	

}
