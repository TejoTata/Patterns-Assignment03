/**
 * 
 */
package ThrowsClassDemo;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class SubClassDemo extends SuperClassDemo {

		      void msg() throws ArithmeticException {
		      System.out.println("Hello");
		}

}
