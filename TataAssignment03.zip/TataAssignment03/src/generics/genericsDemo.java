/**
 * 
 */
package generics;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class genericsDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		genericsClass<String> stringClass = new genericsClass<>("Hello, world!");
		String value = stringClass.getValue(); // value is "Hello, world!"


	}

}
