/**
 * 
 */
package generics;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class genericsClass<T> {
	    private T value;

	    public genericsClass(T value) {
	        this.value = value;
	    }

	    public T getValue() {
	        return value;
	    }

	    public void setValue(T value) {
	        this.value = value;
	    }
	}



