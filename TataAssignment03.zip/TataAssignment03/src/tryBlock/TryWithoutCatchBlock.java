/**
 * 
 */
package tryBlock;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class TryWithoutCatchBlock {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
	         System.out.println("Printing Try Block");
	      } finally {
	         System.out.println("Entering Finally Block");
	      }

	}

}
