/**
 * 
 */
package finalDemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class Finallyblock {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileInputStream file = null;
		try {
			System.out.println("Inside try block");  
		    file = new FileInputStream("finally.txt");
		    // read from file
		} catch (FileNotFoundException e) {
		    // handle exception
		} finally {
		    try {
		        file.close();
		    } catch (IOException e) {
		        // handle exception
		    }
		}

	}

}
