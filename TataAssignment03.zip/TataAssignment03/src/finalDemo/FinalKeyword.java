/**
 * 
 */
package finalDemo;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class FinalKeyword {
	final int x = 10;
	//x = 20; // Error: cannot assign a value to final variable x
	

}
