/**
 * 
 */
package java8features;

import java.util.Arrays;
import java.util.List;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class lamdaExpression {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> fruits = Arrays.asList("apple", "banana", "orange", "kiwi");
		fruits.forEach(fruit -> System.out.println(fruit));



	}

}
