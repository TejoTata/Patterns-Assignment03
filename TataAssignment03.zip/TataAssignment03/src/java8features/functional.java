/**
 * 
 */
package java8features;

import java.time.LocalDateTime;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class functional {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LocalDateTime currentDateTime = LocalDateTime.now();
		System.out.println("Current Date and Time: " + currentDateTime);

	}

}
