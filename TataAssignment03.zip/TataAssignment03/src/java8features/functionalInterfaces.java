/**
 * 
 */
package java8features;

import java.util.function.Function;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class functionalInterfaces {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Function<Integer, Integer> square = x -> x * x;
		System.out.println(square.apply(5));

	}

}
