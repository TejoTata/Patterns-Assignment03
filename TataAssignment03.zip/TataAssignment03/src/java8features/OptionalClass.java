/**
 * 
 */
package java8features;

import java.util.Optional;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class OptionalClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] str1 = new String[10]; 
        Optional<String> ing = Optional.ofNullable(str1[5]); 
        if (ing.isPresent()) { 
            String word = str1[5].toLowerCase(); 
            System.out.print(str1); 
         } else
           System.out.println("string is null"); 

	}


}
