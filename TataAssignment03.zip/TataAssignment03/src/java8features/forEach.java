/**
 * 
 */
package java8features;

import java.util.Arrays;
import java.util.List;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class forEach {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

		numbers.forEach((Integer value) -> System.out.println(value));


	}

}
