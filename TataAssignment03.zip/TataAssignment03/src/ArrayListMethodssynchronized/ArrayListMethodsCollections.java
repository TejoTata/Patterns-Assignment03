/**
 * 
 */
package ArrayListMethodssynchronized;

/**
 * @author Tejo Lakshmi Tata
 *
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ArrayListMethodsCollections {

		    public static void main(String[] args) {
		        // Creating a non-synchronized ArrayList
		        List<String> list = new ArrayList<>();

		        // Adding elements to the list
		        list.add("apple");
		        list.add("banana");
		        list.add("cherry");

		        // Making the list synchronized using Collections.synchronizedList()
		        List<String> synchronizedList = Collections.synchronizedList(list);

		        // Adding elements to the synchronized list using synchronized block
		        synchronized(synchronizedList) {
		            synchronizedList.add("dog");
		            synchronizedList.add("cat");
		            synchronizedList.add("bird");
		        }

		        // Using CopyOnWriteArrayList
		        List<String> copyOnWriteList = new CopyOnWriteArrayList<>(list);
		        copyOnWriteList.add("elephant");
		        
		        
		        Iterator<String> itr = list.iterator(); 
			    while(itr.hasNext())
			    { 
			      String str = itr.next(); 
			      System.out.println(str); 
			    } 
		    }
		

	}


