/**
 * 
 */
package TryWithResources;

import java.io.FileOutputStream;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try(FileOutputStream fileOutputStream =new FileOutputStream("java.txt")){      
			String str = "Welcome to Unites States of America!";      
			byte byteArray[] = str.getBytes();
			fileOutputStream.write(byteArray);  
			System.out.println("Message successfully written to file!");      
			}
		catch(Exception exception){  
			       System.out.println(exception);  
			}   
	}

}
