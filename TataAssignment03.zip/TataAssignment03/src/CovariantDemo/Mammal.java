/**
 * 
 */
package CovariantDemo;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class Mammal extends Animal {
	 public Mammal reproduce() {
	        System.out.println("Mammal is reproducing.");
	        return new Mammal();
	    }
	 @Override
	 public void move() {
			System.out.println("Mammal is producing");
		}

}
