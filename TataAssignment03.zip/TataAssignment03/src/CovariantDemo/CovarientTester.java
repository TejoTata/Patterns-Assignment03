/**
 * 
 */
package CovariantDemo;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class CovarientTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Mammal().getInstance().move();


	}

}
