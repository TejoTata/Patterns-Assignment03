/**
 * 
 */
package thread;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class Threaddemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		        Thread thread = new Thread(() -> {
		            System.out.println("Thread started");
		        });

		        thread.start(); // Start the thread
		        thread.start(); // Try to start the thread again

		        // Output:
		        // Thread started
		        // Exception in thread "main" java.lang.IllegalThreadStateException
		        //     at java.base/java.lang.Thread.start(Thread.java:802)
		        //     at Main.main(Main.java:9)
		    }
		

	}


