/**
 * 
 */
package pureSingleton;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class EagerSingleton {
	
	    private static final EagerSingleton instance = new EagerSingleton();

	    private EagerSingleton() {
	        // private constructor
	    }

	    public static EagerSingleton getInstance() {
	        return instance;
	    }
	}



