/**
 * 
 */
package pureSingleton;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class LazySingleton {
    private static LazySingleton instance;

    private LazySingleton() {
        // private constructor
    }

    public static synchronized LazySingleton getInstance() {
        if (instance == null) {
            instance = new LazySingleton();
        }
        return instance;
    }
}
