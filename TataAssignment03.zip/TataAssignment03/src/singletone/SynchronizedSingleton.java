/**
 * 
 */
package singletone;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class SynchronizedSingleton {
	 private static volatile SynchronizedSingleton instance;
	   
	   private SynchronizedSingleton() {}
	   
	   public static synchronized SynchronizedSingleton getInstance() {
	      if(instance == null) {
	         instance = new SynchronizedSingleton();
	      }
	      return instance;
	   }

}
