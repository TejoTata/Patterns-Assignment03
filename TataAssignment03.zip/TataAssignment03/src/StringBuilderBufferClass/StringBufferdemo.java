/**
 * 
 */
package StringBuilderBufferClass;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class StringBufferdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 StringBuffer buffer = new StringBuffer(" Hi");
	      buffer.append(" Java 8");
	      System.out.println("StringBuffer Example" +buffer);
	}

}
