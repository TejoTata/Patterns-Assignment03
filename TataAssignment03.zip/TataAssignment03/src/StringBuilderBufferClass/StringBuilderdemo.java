/**
 * 
 */
package StringBuilderBufferClass;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class StringBuilderdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 StringBuilder build =new StringBuilder(" Hello");
	      build.append("  World!");
	      System.out.println("StringBuilder example " +build);

	}

}
