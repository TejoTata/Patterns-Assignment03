/**
 * 
 */
package StringBuilderBufferClass;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class StringClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				String str=new String ("Hello ");
				str.concat("   World");
				System.out.println(str);

	}

}
