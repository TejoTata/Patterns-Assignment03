/**
 * 
 */
package override;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class Animal {
	
	    public static void makeSound() {
	        System.out.println("Animal is making a sound.");
	    }
	}

	

	

