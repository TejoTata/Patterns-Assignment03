/**
 * 
 */
package override;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class OverrideDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		  
		        Animal.makeSound(); // Output: Animal is making a sound.
		        Cat.makeSound(); // Output: cat is barking.
		    }
	
	}


