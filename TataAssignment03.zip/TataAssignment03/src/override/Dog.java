/**
 * 
 */
package override;

/**
 * @author Tejo Lakshmi Tata
 *
 */

	class Cat extends Animal {
	    public static void makeSound() {
	        System.out.println("Cat is Screming.");
	    }
	}


