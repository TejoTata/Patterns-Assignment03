/**
 * 
 */
package immutable;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class StringImmutable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "Hello";
		str.concat(" World");
		System.out.println("str1 refers to " + str); // prints "Hello"


	}

}
