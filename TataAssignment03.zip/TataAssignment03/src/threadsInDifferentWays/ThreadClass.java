/**
 * 
 */
package threadsInDifferentWays;

/**
 * @author Tejo Lakshmi Tata
 *
 */
public class ThreadClass extends Thread {

	    @Override
	    public void run() {
	        System.out.println("Thread running");
	    }
	


	    public static void main(String[] args) {
	    	ThreadClass myThread = new ThreadClass();
	        myThread.start();
	    }
	}


